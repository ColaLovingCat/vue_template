export const dataTypes = [
  { value: "string", title: "字符串" },
  { value: "number", title: "数值" },
  { value: "integer", title: "整型" },
  { value: "boolean", title: "布尔型" },
  { value: "datetime", title: "时间" },
  { value: "object", title: "对象" },
  { value: "file", title: "文件" },
  { value: "array", title: "数组" },
];
